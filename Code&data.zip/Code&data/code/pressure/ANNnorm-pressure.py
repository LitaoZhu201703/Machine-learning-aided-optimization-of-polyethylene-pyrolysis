import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam, Adadelta, Adagrad, RMSprop, SGD
from tensorflow.keras.losses import Huber
from sklearn.model_selection import KFold
from skopt import gp_minimize
from skopt.space import Real, Integer, Categorical
from sklearn.metrics import mean_squared_error
import time
import os
import os
import joblib
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  
tf.autograph.set_verbosity(0, True)  


np.random.seed(42)
tf.random.set_seed(42)
def computeCorrelation(x, y):
    xBar = np.mean(x)
    yBar = np.mean(y)
    diffxxBar = x - xBar
    diffyyBar = y - yBar
    SSR = np.sum(diffxxBar * diffyyBar)
    SSxx = np.sum(diffxxBar ** 2)
    SSyy = np.sum(diffyyBar ** 2)
    epsilon = 1e-10  
    corr = SSR / np.sqrt((SSxx + epsilon) * (SSyy + epsilon))  
    mape = np.mean(np.abs((y - x) / (y + epsilon)))  
    return corr, mape


da = pd.read_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end.csv")
data = np.array(da)
dataa = data.copy()


dataa[:, 0] = (data[:, 0] - np.min(data[:, 0])) / (np.max(data[:, 0]) - np.min(data[:, 0]))  
dataa[:, 1] = (data[:, 1] - np.min(data[:, 1])) / (np.max(data[:, 1]) - np.min(data[:, 1]))  
dataa[:, 2] = (data[:, 2] - np.min(data[:, 2])) / (np.max(data[:, 2]) - np.min(data[:, 2]))  
dataa[:, 3] = (data[:, 3] - np.min(data[:, 3])) / (np.max(data[:, 3]) - np.min(data[:, 3]))  


dataa[:, 5] = (data[:, 5] - np.min(data[:, 5])) / (np.max(data[:, 5]) - np.min(data[:, 5]))  

delta=(np.max(data[:, 5]) - np.min(data[:, 5])) 
delta_min=np.min(data[:, 5])

xaa = dataa[:, :4]  
ya = dataa[:, 5]    


fixed_train_xa = xaa[:12]
fixed_train_ya = ya[:12]
remaining_xa = xaa[12:]
remaining_ya = ya[12:]



space = [
    Real(0.001, 0.1, name="learning_rate"),  
    Categorical(np.arange(50, 5000, 100).tolist(), name="epochs"),  
    Categorical(["4", "8", "16", "32", "8,16", "16,8", "16,16", "8,16,8", "8,16,16", "8,16,16,16", "8,16,16,32", "8,16,16,16,16"], name="hidden_layers"),  
    
    Categorical(["relu", "tanh", "elu"], name="activation"),  
    
    Categorical(["huber", "mape", "mae"], name="loss"),  
    
    Categorical(["adam", "adadelta", "adagrad", "rmsprop", "sgd"], name="optimizer"),  
    Integer(10, 500, name="batch_size"),  
]


all_iterations = []


def create_model(params):
    learning_rate = params[0]
    hidden_layers = params[2]
    activation = params[3]
    optimizer_name = params[4]  
    
    
    layers_config = list(map(int, hidden_layers.split(',')))
    
    
    model = Sequential()
    
    
    model.add(Dense(layers_config[0], activation=activation, input_shape=(4,)))
    model.add(tf.keras.layers.Dropout(0.2))  
    
    for neurons in layers_config[1:]:
        model.add(Dense(neurons, activation=activation))
        model.add(tf.keras.layers.Dropout(0.2))  
    
    model.add(Dense(1, activation='relu'))  
    
    
    if optimizer_name == "adam":
        opt = Adam(learning_rate=learning_rate)
    elif optimizer_name == "adadelta":
        opt = Adadelta(learning_rate=learning_rate)
    elif optimizer_name == "adagrad":
        opt = Adagrad(learning_rate=learning_rate)
    elif optimizer_name == "rmsprop":
        opt = RMSprop(learning_rate=learning_rate)
    elif optimizer_name == "sgd":
        opt = SGD(learning_rate=learning_rate)
    else:
        
        opt = Adam(learning_rate=learning_rate)
    
    
    loss = params[4]
    model.compile(optimizer=opt, loss=loss, metrics=['mape'])
    
    return model




def multi_objective(params, weights=[0.33, 0.33, 0.34], iteration=None):
    """
    weights: [RMSE权重, MAPE权重, 相关系数权重]
    iteration: 当前迭代次数（用于日志）
    """
    learning_rate = params[0]
    epochs = params[1]
    hidden_layers = params[2]
    activation = params[3]
    loss = params[4]
    optimizer = params[5]
    batch_size = params[6]
    
    params_dict = {
        "learning_rate": learning_rate,
        "epochs": epochs,
        "hidden_layers": hidden_layers,
        "activation": activation,
        "loss": loss,
        "optimizer": optimizer,
        "batch_size": batch_size
    }
    
    rmse_scores = []
    mape_scores = []
    corr_scores = []
    
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    
    for fold_idx, (train_idx, val_idx) in enumerate(kf.split(remaining_xa)):
        
        train_remaining_xa = remaining_xa[train_idx]
        train_remaining_ya = remaining_ya[train_idx]
        val_xa = remaining_xa[val_idx]
        val_ya = remaining_ya[val_idx]
        x_train = np.vstack([fixed_train_xa, train_remaining_xa])
        y_train = np.hstack([fixed_train_ya, train_remaining_ya])
        
        
        model = create_model(params)
        
        
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True,
            mode='min'
        )
        
        model.fit(
            x_train, y_train,
            epochs=epochs,
            batch_size=batch_size,
            validation_data=(val_xa, val_ya),
            callbacks=[early_stopping],
            verbose=0
        )
        
        
        y_pred = model.predict(val_xa).flatten()
        
        
        y_real = val_ya * delta + delta_min
        y_pred_real = y_pred * delta + delta_min
        
        
        rmse = mean_squared_error(y_real, y_pred_real, squared=False)
        corr, mape = computeCorrelation(y_real, y_pred_real)
        
        rmse_scores.append(rmse)
        mape_scores.append(mape)
        corr_scores.append(corr)
        
        
        tf.keras.backend.clear_session()
    
    
    rmse_mean = np.mean(rmse_scores)
    mape_mean = np.mean(mape_scores)
    corr_mean = np.mean(corr_scores)
    
    
    corr_norm = (1 - corr_mean)  
    
    
    total_objective = weights[0]*rmse_mean + weights[1]*mape_mean + weights[2]*corr_norm
    
    
    all_iterations.append({
        "params": params_dict,
        "rmse": rmse_mean,
        "mape": mape_mean,
        "correlation": corr_mean,
        "total_objective": total_objective
    })
    
    
    print(f"迭代 {iteration} | 参数: {params_dict}")
    print(f"  → 汇总指标 | RMSE: {rmse_mean:.4f}, MAPE: {mape_mean:.2f}%, 相关系数: {corr_mean:.4f}")
    print(f"  → 加权目标: {total_objective:.4f}")
    
    return total_objective


print("开始多目标贝叶斯优化（权重=RMSE:MAPE:Corr=0.33:0.33:0.34）...")
result = gp_minimize(
    lambda params: multi_objective(params, iteration=len(all_iterations)+1),
    space,
    n_calls=30,  
    random_state=42,
    verbose=1
)


best_params = dict(zip([dim.name for dim in space], result.x))
best_iteration = min(all_iterations, key=lambda x: x['total_objective'])


perm = np.random.permutation(len(remaining_xa))
split_idx = int(len(remaining_xa) * 0.8)
train_remaining_xa = remaining_xa[perm[:split_idx]]
train_remaining_ya = remaining_ya[perm[:split_idx]]
val_xa = remaining_xa[perm[split_idx:]]
val_ya = remaining_ya[perm[split_idx:]]
x_train_final = np.vstack([fixed_train_xa, train_remaining_xa])
y_train_final = np.hstack([fixed_train_ya, train_remaining_ya])



best_model = create_model(result.x)


early_stopping = tf.keras.callbacks.EarlyStopping(
    monitor='val_loss',
    patience=10,
    restore_best_weights=True
)

best_model.fit(
    x_train_final, y_train_final,
    epochs=best_params['epochs'],
    batch_size=best_params['batch_size'],
    validation_data=(val_xa, val_ya),
    callbacks=[early_stopping],
    verbose=1
)


y_pred = best_model.predict(val_xa).flatten()


y_real = val_ya * delta + delta_min
y_pred_real = y_pred * delta + delta_min


rmse = mean_squared_error(y_real, y_pred_real, squared=False)
corr, mape = computeCorrelation(y_real, y_pred_real)


print("\n\n=== 优化结果 ===")
print(f"最优参数组合: {best_params}")
print(f"验证集性能: RMSE={rmse:.4f}, MAPE={mape:.2f}%, 相关系数={corr:.4f}")


try:
    import pandas as pd
    df = pd.DataFrame(all_iterations)

    params_df = pd.json_normalize(df['params'])

    
    result = pd.concat([df.drop("params", axis=1), params_df], axis=1)
    new_order = ['learning_rate', 'epochs', 'hidden_layers', 'activation', 'loss', 'optimizer', 'batch_size', 'rmse', 'mape', 'correlation', 'total_objective']
    result = result.reindex(columns=new_order)
    print(result)
    result.to_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\ANN\\norm_pressure_ANN5000.csv", index=False)
    print("\n所有迭代结果已保存至 'bayesian_optimization_results_ANN.csv'")
except ImportError:
    print("\n警告: 未安装pandas，无法保存结果到CSV")




joblib.dump(best_model,'C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\ANN\\norm_pressure.pkl')



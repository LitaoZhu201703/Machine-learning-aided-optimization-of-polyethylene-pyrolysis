#include "udf.h"
#include "stdio.h"
#include "math.h"
#include "sg_pb.h"
#include "sg_mphase.h"
real Ro_s = 931; 
real Ro_sand = 2585;
real Ro_g, void_g, Temp, void_HDPE, species_s, void_sands;
real K_0, K_1, K_2, K_3, K_4;
real R_HDPE1, R_HDPE2, R_HDPE3, R_HDPE4, R_gas1, R_gas2, R_gas3, R_gas4, R_c51, R_c52, R_c53, R_c54, R_c111, R_c112, R_c113, R_c114, R_c161, R_c162, R_c163, R_c164, R_c211, R_c212, R_c213, R_c214;
real R_gas, R_c5, R_c11, R_c16, R_c21, R_HDPE;
real S_HDPE, S_gas, S_c5, S_c11, S_c16, S_c21;
real he1, he2, he3, he4;
real ratio_HDPE = 0.05;
real species_HDPE, R_inter, species_inter;
real judge_zero, delta;
real A[4] = {33.583, 36.016, 23.126, 34.124};
real n[4] = {0.280, 0.512, 0.147, 0.201};
real E[4] = {265649.0, 284333.0, 193142.0, 249107.0};


real steady_state_func(real y, real K0, real K1, real K2, real K3, real K4, real* alpha, real void_HDPE_val) {
    real x1 = void_HDPE_val * y; 
    
    real f_forward = K0 * alpha[0] * pow(void_HDPE_val * (1 - y), alpha[0]); 
    
    real f_backward = K1 * alpha[1] * pow(void_HDPE_val * y, alpha[1]) +
                      K2 * alpha[2] * pow(void_HDPE_val * y, alpha[2]) +
                      K3 * alpha[3] * pow(void_HDPE_val * y, alpha[3]) +
                      K4 * alpha[4] * pow(void_HDPE_val * y, alpha[4]); 
    return f_forward - f_backward; 
}


real newton_method_for_y(real* alpha, real T, real void_HDPE_val, real tol, int max_iter) {
    real Temp = T ; 
    
    real K0 = exp(28.337 + 0.023 * log(Temp) - 203605.0 / (8.314 * Temp));
    real K1 = exp(A[0] + n[0] * log(Temp) - E[0] / (8.314 * Temp));
    real K2 = exp(A[1] + n[1] * log(Temp) - E[1] / (8.314 * Temp));
    real K3 = exp(A[2] + n[2] * log(Temp) - E[2] / (8.314 * Temp));
    real K4 = exp(A[3] + n[3] * log(Temp) - E[3] / (8.314 * Temp));

    real y_guess;
    if (void_HDPE_val < 1e-5) {
        y_guess = 0.01; 
    } else {
        y_guess = 0.5;
    }
    real y_new;
    real fy;
    int iter;

    for (iter = 0; iter < max_iter; iter++) {
        fy = steady_state_func(y_guess, K0, K1, K2, K3, K4, alpha, void_HDPE_val);

        if (fabs(fy) < tol) { 
            break;
        }

        
        real h = 1e-8 * fmax(1.0, y_guess);
        real df_dy = (steady_state_func(y_guess + h, K0, K1, K2, K3, K4, alpha, void_HDPE_val) 
                    - steady_state_func(y_guess - h, K0, K1, K2, K3, K4, alpha, void_HDPE_val)) 
                    / (2 * h);

         if (fabs(df_dy) < 1e-12) {
                        
             h = 1e-12;
             df_dy = (steady_state_func(y_guess + h, K0, K1, K2, K3, K4, alpha, void_HDPE_val) 
                      - steady_state_func(y_guess, K0, K1, K2, K3, K4, alpha, void_HDPE_val)) / h;
            if (fabs(df_dy) < 1e-12) {
                break; 
                        }
                    }

        y_new = y_guess - fy / df_dy; 
        y_new = fmax(0.0, fmin(y_new, 1.0)); 
        y_guess = y_new;
    }

    if (iter == max_iter) {
        if (void_HDPE_val < 1e-8) {
            return 0.0; 
        }
    }

    return y_guess;
}

DEFINE_EXECUTE_AT_END(reactionrate)
{
    Domain *d;
    Thread *t;
    cell_t c;
    real alpha[5] = {0.415, 0.479, 0.885, 0.404, 1.505}; 
    real tol = 1e-3; 
    int max_iter = 200; 

    d = Get_Domain(2);
    thread_loop_c(t, d)
    {
        begin_c_loop(c, t)
        {
            
            Ro_g = C_R(c, t);          
            void_g = C_VOF(c, t);      
            Temp = 600+ 273.15;       

            
            S_HDPE = 0.0;
            S_gas = 0.0;
            S_c5 = 0.0;
            S_c11 = 0.0;
            S_c16 = 0.0;
            S_c21 = 0.0;

            
            void_HDPE = (1 - void_g) * ratio_HDPE;

            
            real y_ssa = newton_method_for_y(alpha, Temp, void_HDPE, tol, max_iter);
            

            
            species_s =void_HDPE * y_ssa; 

            
            K_1 = exp(A[0] + n[0] * log(Temp) - E[0] / 8.314 / Temp);
            R_HDPE1 = -K_1 * 0.479 * pow(species_s, 0.479) * (Ro_s * species_s);
            he1 = 0.045 + 0.114 + 0.145 + 0.116 + 0.059;
            R_gas1 = -R_HDPE1 * (0.045 / he1);
            R_c51 = -R_HDPE1 * (0.114 / he1);
            R_c111 = -R_HDPE1 * (0.145 / he1);
            R_c161 = -R_HDPE1 * (0.116 / he1);
            R_c211 = -R_HDPE1 * (0.059 / he1);

            K_2 = exp(A[1] + n[1] * log(Temp) - E[1] / 8.314 / Temp);
            R_HDPE2 = -K_2 * 0.885 * pow(species_s, 0.885) * (Ro_s * species_s);
            he2 = 0.149 + 0.330 + 0.182 + 0.081 + 0.143;
            R_gas2 = -R_HDPE2 * (0.149 / he2);
            R_c52 = -R_HDPE2 * (0.330 / he2);
            R_c112 = -R_HDPE2 * (0.182 / he2);
            R_c162 = -R_HDPE2 * (0.081 / he2);
            R_c212 = -R_HDPE2 * (0.143 / he2);

            K_3 = exp(A[2] + n[2] * log(Temp) - E[2] / 8.314 / Temp);
            R_HDPE3 = -K_3 * 0.404 * pow(species_s, 0.404) * (Ro_s * species_s);
            he3 = 0.003 + 0.002 + 0.0 + 0.052 + 0.347;
            R_gas3 = -R_HDPE3 * (0.003 / he3);
            R_c53 = -R_HDPE3 * (0.002 / he3);
            R_c113 = -R_HDPE3 * (0.0 / he3);
            R_c163 = -R_HDPE3 * (0.052 / he3);
            R_c213 = -R_HDPE3 * (0.347 / he3);

            K_4 = exp(A[3] + n[3] * log(Temp) - E[3] / 8.314 / Temp);
            R_HDPE4 = -K_4 * 1.505 * pow(species_s, 1.505) * (Ro_s * species_s);
            he4 = 0.007 + 0.151 + 0.147 + 0.197 + 1.003;
            R_gas4 = -R_HDPE4 * (0.007 / he4);
            R_c54 = -R_HDPE4 * (0.151 / he4);
            R_c114 = -R_HDPE4 * (0.147 / he4);
            R_c164 = -R_HDPE4 * (0.197 / he4);
            R_c214 = -R_HDPE4 * (1.003 / he4);

            
            R_HDPE = -(R_HDPE1 + R_HDPE2 + R_HDPE3 + R_HDPE4);
            R_gas = R_gas1 + R_gas2 + R_gas3 + R_gas4;
            R_c5 = R_c51 + R_c52 + R_c53 + R_c54;
            R_c11 = R_c111 + R_c112 + R_c113 + R_c114;
            R_c16 = R_c161 + R_c162 + R_c163 + R_c164;
            R_c21 = R_c211 + R_c212 + R_c213 + R_c214;

            
            C_UDMI(c, t, 0) = S_HDPE = R_HDPE;
            C_UDMI(c, t, 1) = S_gas = R_gas;
            C_UDMI(c, t, 2) = S_c5 = R_c5;
            C_UDMI(c, t, 3) = S_c11 = R_c11;
            C_UDMI(c, t, 4) = S_c16 = R_c16;
            C_UDMI(c, t, 5) = S_c21 = R_c21;
            C_UDMI(c, t, 6) = void_HDPE;
            C_UDMI(c, t, 7) = species_s;
            C_UDMI(c, t, 8) = y_ssa;
            C_UDMI(c, t, 10) = Temp;

        }
        end_c_loop(c, t)
    }
}
DEFINE_SOURCE(g_gas, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 1);
    dS[eqn] = 0.0; 
    return mass;
}

DEFINE_SOURCE(gas_c5_c10, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 2);
    dS[eqn] = 0.0;
    return mass;
}

DEFINE_SOURCE(gas_c11_c15, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 3);
    dS[eqn] = 0.0;
    return mass;
}

DEFINE_SOURCE(gas_c16_c20, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 4);
    dS[eqn] = 0.0;
    return mass;
}

DEFINE_SOURCE(gas_c21, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 5);
    dS[eqn] = 0.0;
    return mass;
}

DEFINE_SOURCE(Solid_HDPE, c, t, dS, eqn)     
{
    real mass = C_UDMI(c, t, 0);
    dS[eqn] = 0.0;
    return mass;
}    
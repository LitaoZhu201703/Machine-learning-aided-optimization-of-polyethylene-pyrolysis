import numpy as np
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, DotProduct, RationalQuadratic
from sklearn.model_selection import KFold
from skopt import gp_minimize
from skopt.space import Real, Integer, Categorical
from sklearn.metrics import mean_squared_error
import time
import matplotlib.pyplot as plt


def computeCorrelation(x, y):
    xBar = np.mean(x)
    yBar = np.mean(y)
    diffxxBar = x - xBar
    diffyyBar = y - yBar
    SSR = np.sum(diffxxBar * diffyyBar)
    SSxx = np.sum(diffxxBar ** 2)
    SSyy = np.sum(diffyyBar ** 2)
    epsilon = 1e-10  
    corr = SSR / np.sqrt((SSxx + epsilon) * (SSyy + epsilon))  
    mape = np.mean(np.abs((y - x) / (y + epsilon)))  
    return corr, mape


da = pd.read_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end.csv")
data = np.array(da)
dataa = data.copy()


dataa[:, 0] = (data[:, 0] - np.min(data[:, 0])) / (np.max(data[:, 0]) - np.min(data[:, 0]))  
dataa[:, 1] = (data[:, 1] - np.min(data[:, 1])) / (np.max(data[:, 1]) - np.min(data[:, 1]))  
dataa[:, 2] = (data[:, 2] - np.min(data[:, 2])) / (np.max(data[:, 2]) - np.min(data[:, 2]))  
dataa[:, 3] = (data[:, 3] - np.min(data[:, 3])) / (np.max(data[:, 3]) - np.min(data[:, 3]))  

xaa = dataa[:, :4]  
ya = dataa[:, 4]    


fixed_train_xa = xaa[:12]
fixed_train_ya = ya[:12]
remaining_xa = xaa[12:]
remaining_ya = ya[12:]


def get_kernel(kernel_type):
    if kernel_type == 'RBF':
        return RBF()
    elif kernel_type == 'Matern':
        return Matern(nu=1.5)  
    elif kernel_type == 'DotProduct':
        return DotProduct()
    elif kernel_type == 'RationalQuadratic':
        return RationalQuadratic()
    elif kernel_type == 'RBF+DotProduct':
        return RBF() + DotProduct()
    elif kernel_type == 'Matern+DotProduct':
        return Matern(nu=1.5) + DotProduct()
    else:
        raise ValueError(f"不支持的核函数类型: {kernel_type}")


all_iterations = []


def multi_objective(params, weights=[0.33, 0.33, 0.34], iteration=None):
    """
    weights: [RMSE权重, MAPE权重, 相关系数权重]
    iteration: 当前迭代次数（用于日志）
    """
    kernel_type = params[0]
    n_restarts_optimizer = params[1]
    
    params_dict = {
        "kernel_type": kernel_type,
        "n_restarts_optimizer": n_restarts_optimizer,
    }
    
    
    kernel = get_kernel(kernel_type)
    
    
    model = GaussianProcessRegressor(
        kernel=kernel,
        n_restarts_optimizer=n_restarts_optimizer,
        alpha=1e-10,  
        random_state=42
    )
    
    rmse_scores = []
    mape_scores = []
    corr_scores = []
    
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    
    for train_idx, val_idx in kf.split(remaining_xa):
        
        train_remaining_xa = remaining_xa[train_idx]
        train_remaining_ya = remaining_ya[train_idx]
        val_xa = remaining_xa[val_idx]
        val_ya = remaining_ya[val_idx]
        x_train = np.vstack([fixed_train_xa, train_remaining_xa])
        y_train = np.hstack([fixed_train_ya, train_remaining_ya])
        
        
        model.fit(x_train, y_train)
        y_pred = model.predict(val_xa)
        
        
        rmse = mean_squared_error(val_ya, y_pred, squared=False)
        corr, mape = computeCorrelation(val_ya, y_pred)
        
        rmse_scores.append(rmse)
        mape_scores.append(mape)
        corr_scores.append(corr)
    
    
    rmse_mean = np.mean(rmse_scores)
    mape_mean = np.mean(mape_scores)
    corr_mean = np.mean(corr_scores)
    
    
    corr_norm = (1 - corr_mean)  
    
    
    total_objective = weights[0]*rmse_mean + weights[1]*mape_mean + weights[2]*corr_norm
    
    
    all_iterations.append({
        "params": params_dict,
        "rmse": rmse_mean,
        "mape": mape_mean,
        "correlation": corr_mean,
        "total_objective": total_objective
    })
    
    
    print(f"迭代 {iteration}: 参数 = {params_dict}")
    print(f"  → 汇总指标 | RMSE: {rmse_mean:.4f}, MAPE: {mape_mean:.6f}, 相关系数: {corr_mean:.4f}")
    print(f"  → 加权目标: {total_objective:.4f}")
    
    return total_objective


space = [
    Categorical(['RBF', 'Matern', 'DotProduct', 'RationalQuadratic', 'RBF+DotProduct', 'Matern+DotProduct'], name="kernel_type"),
    Integer(1, 100, name="n_restarts_optimizer"),  
]


print("开始多目标贝叶斯优化（权重=RMSE:MAPE:Corr=0.33:0.33:0.34）...")
result = gp_minimize(
    lambda params: multi_objective(params, iteration=len(all_iterations)+1),
    space,
    n_calls=30,  
    random_state=42,
)


best_params = dict(zip([dim.name for dim in space], result.x))
best_iteration = min(all_iterations, key=lambda x: x['total_objective'])


perm = np.random.permutation(len(remaining_xa))
split_idx = int(len(remaining_xa) * 0.8)
train_remaining_xa = remaining_xa[perm[:split_idx]]
train_remaining_ya = remaining_ya[perm[:split_idx]]
val_xa = remaining_xa[perm[split_idx:]]
val_ya = remaining_ya[perm[split_idx:]]
x_train_final = np.vstack([fixed_train_xa, train_remaining_xa])
y_train_final = np.hstack([fixed_train_ya, train_remaining_ya])


best_kernel = get_kernel(best_params['kernel_type'])


best_model = GaussianProcessRegressor(
    kernel=best_kernel,
    n_restarts_optimizer=best_params['n_restarts_optimizer'],
    alpha=1e-10,
    random_state=42
)

best_model.fit(x_train_final, y_train_final)
y_pred = best_model.predict(val_xa)
rmse = mean_squared_error(val_ya, y_pred, squared=False)
corr, mape = computeCorrelation(val_ya, y_pred)


print("\n\n=== 优化结果 ===")
print(f"最优参数: {best_params}")
print(f"验证集性能: RMSE={rmse:.4f}, MAPE={mape:.6f}, 相关系数={corr:.4f}")


try:
    import pandas as pd
    df = pd.DataFrame(all_iterations)
    df.to_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\gpr\\bayesian_oil.csv", index=False)
    print("\n所有迭代结果已保存至 'bayesian_optimization_results.csv'")
except ImportError:
    print("\n警告: 未安装pandas，无法保存结果到CSV")


import joblib
joblib.dump(best_model, "C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\gpr\\best_gpr_oil.pkl")

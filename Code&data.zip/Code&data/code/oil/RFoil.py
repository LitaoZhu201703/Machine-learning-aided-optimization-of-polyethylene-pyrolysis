import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold
from sklearn.utils import shuffle
import tensorflow as tf
import joblib
from skopt import gp_minimize
from skopt.space import Integer
import numpy as np
import pandas as pd
import joblib
import os


def computeCorrelation(x, y):
    xBar = np.mean(x)
    yBar = np.mean(y)
    diffxxBar = x - xBar
    diffyyBar = y - yBar
    SSR = np.sum(diffxxBar * diffyyBar)
    SSxx = np.sum(diffxxBar ** 2)
    SSyy = np.sum(diffyyBar ** 2)
    epsilon = 1e-10  
    corr = SSR / np.sqrt((SSxx + epsilon) * (SSyy + epsilon))  
    mape = np.mean(np.abs((y - x) / (y + epsilon))) * 100  
    return corr, mape


da = pd.read_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end.csv")
data = np.array(da)
dataa = data.copy()


dataa[:, 0] = (data[:, 0] - np.min(data[:, 0])) / (np.max(data[:, 0]) - np.min(data[:, 0]))  
dataa[:, 1] = (data[:, 1] - np.min(data[:, 1])) / (np.max(data[:, 1]) - np.min(data[:, 1]))  
dataa[:, 2] = (data[:, 2] - np.min(data[:, 2])) / (np.max(data[:, 2]) - np.min(data[:, 2]))  
dataa[:, 3] = (data[:, 3] - np.min(data[:, 3])) / (np.max(data[:, 3]) - np.min(data[:, 3]))  

xaa = dataa[:, :4]  
ya = dataa[:, 4]    


fixed_train_xa = xaa[:12]
fixed_train_ya = ya[:12]
remaining_xa = xaa[12:]
remaining_ya = ya[12:]


all_iterations = []

def multi_objective(params, weights=[0.33, 0.33, 0.34], iteration=None):
    """
    params: [max_depth, n_estimators]
    weights: [RMSE权重, MAPE权重, 相关系数权重]
    iteration: 当前迭代次数
    """
    params_dict = {
        "max_depth": params[0],
        "n_estimators": params[1]
    }
    
    model = RandomForestRegressor(
        **params_dict,
        random_state=42,  
    )
    
    rmse_scores = []
    corr_scores = []
    mape_scores = []
    
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    
    for train_idx, val_idx in kf.split(remaining_xa):
        
        train_remaining_xa = remaining_xa[train_idx]
        train_remaining_ya = remaining_ya[train_idx]
        val_xa = remaining_xa[val_idx]
        val_ya = remaining_ya[val_idx]
        
        
        x_train = np.vstack([fixed_train_xa, train_remaining_xa])
        y_train = np.hstack([fixed_train_ya, train_remaining_ya])
        
        
        model.fit(x_train, y_train)
        
        
        y_pred = model.predict(val_xa)
        
        
        rmse = mean_squared_error(val_ya, y_pred, squared=False)
        corr, mape = computeCorrelation(val_ya, y_pred)
        
        rmse_scores.append(rmse)
        corr_scores.append(corr)
        mape_scores.append(mape)
    
    
    mean_rmse = np.mean(rmse_scores)
    mean_corr = np.mean(corr_scores)
    mean_mape = np.mean(mape_scores)
    
    
    corr_norm = 1 - mean_corr
    
    
    total_objective = weights[0] * mean_rmse + weights[1] * mean_mape + weights[2] * corr_norm
    
    
    all_iterations.append({
        "params": params_dict,
        "rmse": mean_rmse,
        "mape%": mean_mape,
        "correlation": mean_corr,
        "total_objective": total_objective
    })
    
    
    print(f"迭代 {iteration} | 参数: max_depth={params[0]}, n_estimators={params[1]}")
    print(f"  → 汇总指标 | RMSE: {mean_rmse:.4f}, MAPE: {mean_mape:.2f}%, 相关系数: {mean_corr:.4f}")
    print(f"  → 加权目标: {total_objective:.4f}")
    
    return total_objective


space = [
    Integer(5, 20, name='max_depth'),        
    Integer(10, 200, name='n_estimators')    
]


print("开始多目标贝叶斯优化RF模型（权重=RMSE:MAPE:Corr=0.33:0.33:0.34）...")
result = gp_minimize(
    lambda params: multi_objective(params, iteration=len(all_iterations)+1),
    space,
    n_calls=30,  
    random_state=42,
    verbose=True
)


best_params = dict(zip([dim.name for dim in space], result.x))
best_iteration = min(all_iterations, key=lambda x: x['total_objective'])


perm = np.random.permutation(len(remaining_xa))
split_idx = int(len(remaining_xa) * 0.8)
train_remaining_xa = remaining_xa[perm[:split_idx]]
train_remaining_ya = remaining_ya[perm[:split_idx]]
val_xa = remaining_xa[perm[split_idx:]]
val_ya = remaining_ya[perm[split_idx:]]
x_train_final = np.vstack([fixed_train_xa, train_remaining_xa])
y_train_final = np.hstack([fixed_train_ya, train_remaining_ya])


model = RandomForestRegressor(**best_params, random_state=42, n_jobs=-1)
model.fit(x_train_final, y_train_final)
y_pred = model.predict(val_xa)
rmse = mean_squared_error(val_ya, y_pred, squared=False)
corr, mape = computeCorrelation(val_ya, y_pred)




print("\n贝叶斯优化结果（按总目标值升序排列）：")
for res in sorted(all_iterations, key=lambda x: x['total_objective']):
    params = res['params']
    print(f"max_depth={params['max_depth']}, n_estimators={params['n_estimators']}, "
          f"RMSE={res['rmse']:.4f}, 相关系数={res['correlation']:.4f}, "
          f"MAPE={res['mape%']:.2f}%, 目标值={res['total_objective']:.4f}")


print("\n\n=== 优化结果 ===")
print(f"  max_depth={best_params['max_depth']}, n_estimators={best_params['n_estimators']}")
print(f"验证集性能: RMSE={rmse:.4f}, MAPE={mape:.2f}%, 相关系数={corr:.4f}")


try:
    output_dir = "C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\RF"
    os.makedirs(output_dir, exist_ok=True)
    df = pd.DataFrame(all_iterations)
    df.to_csv(os.path.join(output_dir, "rf_bayesian_optimization_results_oil.csv"), index=False)
    print("\n所有迭代结果已保存至 'rf_bayesian_optimization_results_oil.csv'")
except ImportError:
    print("\n警告: 未安装pandas，无法保存结果到CSV")





try:
    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)
    joblib.dump(model, os.path.join(model_dir, "best_rf_model.pkl"))
    print("最优模型已保存至 'best_rf_model.pkl'")
except Exception as e:
    print(f"\n保存模型失败: {e}")





























































































param_grid = {
    'max_depth': [5, 10, 15, 20],
    'n_estimators': [10, 25, 50, 100, 150, 200]
}


grid_results = []


kf = KFold(n_splits=10, shuffle=True, random_state=42)

print("开始网格搜索（10折交叉验证）...")
for max_depth in param_grid['max_depth']:
    for n_estimators in param_grid['n_estimators']:
        rmse_scores = []
        corr_scores = []
        mape_scores = []
        
        for train_idx, val_idx in kf.split(remaining_xa):
            
            train_remaining_xa = remaining_xa[train_idx]
            train_remaining_ya = remaining_ya[train_idx]
            val_xa = remaining_xa[val_idx]
            val_ya = remaining_ya[val_idx]
            
            
            x_train = np.vstack([fixed_train_xa, train_remaining_xa])
            y_train = np.hstack([fixed_train_ya, train_remaining_ya])
            
            
            rf = RandomForestRegressor(
                max_depth=max_depth,
                n_estimators=n_estimators,
            )
            rf.fit(x_train, y_train)
            
            
            y_pred = rf.predict(val_xa)
            
            
            rmse = mean_squared_error(val_ya, y_pred, squared=False)
            corr, mape = computeCorrelation(val_ya, y_pred)
            
            rmse_scores.append(rmse)
            corr_scores.append(corr)
            mape_scores.append(mape)
        
        
        mean_rmse = np.mean(rmse_scores)
        mean_corr = np.mean(corr_scores)
        mean_mape = np.mean(mape_scores)
        
        grid_results.append({
            'max_depth': max_depth,
            'n_estimators': n_estimators,
            'mean_rmse': mean_rmse,
            'mean_corr': mean_corr,
            'mean_mape': mean_mape
        })
        
        
        print(f"max_depth={max_depth}, n_estimators={n_estimators}: "
              f"RMSE={mean_rmse:.4f}, 相关系数={mean_corr:.4f}, MAPE={mean_mape:.2f}%")


best_params = min(grid_results, key=lambda x: x['mean_rmse'])


print("\n网格搜索结果（按RMSE升序排列）：")
for res in sorted(grid_results, key=lambda x: x['mean_rmse']):
    print(f"max_depth={res['max_depth']}, n_estimators={res['n_estimators']}, "
          f"RMSE={res['mean_rmse']:.4f}, 相关系数={res['mean_corr']:.4f}, "
          f"MAPE={res['mean_mape']:.2f}%")


print("\n最优参数组合：")
print(f"max_depth={best_params['max_depth']}, n_estimators={best_params['n_estimators']}, "
      f"平均RMSE={best_params['mean_rmse']:.4f}, "
      f"平均相关系数={best_params['mean_corr']:.4f}, "
      f"平均MAPE={best_params['mean_mape']:.2f}%")




rf = RandomForestRegressor(
                max_depth=20,
                n_estimators=200,
            )
rf.fit(x_train, y_train)


joblib.dump(model,'C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\RF\\1_oil.pkl')

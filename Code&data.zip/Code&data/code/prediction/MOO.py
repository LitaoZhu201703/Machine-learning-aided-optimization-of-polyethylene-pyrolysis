import random
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
import joblib
from deap import base, creator, tools, algorithms
import matplotlib.pyplot as plt
import pandas as pd
Gboost_flowrate = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\mul_optimazation\\end\\norm_oil.pkl")


Gboost_pressuredropGPR = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end\\norm_Pressure.pkl")

np.random.seed(42)

X_train = np.random.uniform(
    low=[500, 0.05,0.04, 1.5],
    high=[675, 0.2,0.04, 5.5],
    size=(5000, 4)
)


denominators = np.array([675-500, 0.2-0.05, 0.05,5.5-1.5])  
X_train_normalized = (X_train - np.array([500, 0.05, 0.03,1.5])) / denominators

y_flowrate_train = Gboost_flowrate.predict(X_train_normalized)
y_flowrate_train_end=y_flowrate_train*0.20357741299999998+0.461649184




y_pressure=Gboost_pressuredropGPR .predict(X_train_normalized)
y_pressuredrop_train_end= y_pressure*744.1694488+427.8926812



VAR_RANGES = [
    ('温度', 500, 675),   
    ('比例', 0.05, 0.2),   
    ('patch', 0.04, 0.04),   
    ('速度', 1.5, 5.5)  
]

CUSTOM_NORM_PARAMS = [
    ('温度', 500, 675),   
    ('比例', 0.05, 0.2),    
    ('patch', 0.03, 0.08),   
    ('速度', 1.5, 5.5)     
]



creator.create("FitnessMulti", base.Fitness, weights=(-1.0, -1.0))
creator.create("Individual", list, fitness=creator.FitnessMulti)

toolbox = base.Toolbox()


def create_individual():
    return [
        random.uniform(low, high) 
        for _, low, high in VAR_RANGES
    ]
toolbox.register("individual", tools.initIterate, creator.Individual, create_individual)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)


def evaluate(individual):
    
    norm_vars = []
    for i, (_, custom_low, custom_high) in enumerate(CUSTOM_NORM_PARAMS):
        val = individual[i]
        norm_vars.append( (val - custom_low) /( custom_high -custom_low ))  
    
    flow =float(Gboost_flowrate.predict([norm_vars])[0])
    
    press = float(Gboost_pressuredropGPR.predict([norm_vars])[0])
    
    
    flow = max(flow, 1e-6)  
    return (1/(flow*0.20357741299999998+0.461649184), press*744.1694488+427.8926812)  
    

toolbox.register("evaluate", evaluate)


def check_bounds(mins, maxs):
    def decorator(func):
        def wrapper(*args, **kargs):
            offspring = func(*args, **kargs)
            for child in offspring:
                for i in range(len(child)):
                    child[i] = max(min(child[i], maxs[i]), mins[i])  
            return offspring
        return wrapper
    return decorator


VAR_MINS = [low for _, low, _ in VAR_RANGES]
VAR_MAXS = [high for _, _, high in VAR_RANGES]

sigma = [ (high - low)/30 for _, low, high in VAR_RANGES ]  
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=sigma, indpb=0.3)  
toolbox.register("mate", tools.cxUniform, indpb=0.5)



ref_points = tools.uniform_reference_points(nobj=2, p=20)  
toolbox.register("select", tools.selNSGA3, ref_points=ref_points)


toolbox.mate = check_bounds(VAR_MINS, VAR_MAXS)(toolbox.mate)
toolbox.mutate = check_bounds(VAR_MINS, VAR_MAXS)(toolbox.mutate)





def main(ngen=100):
    pop = toolbox.population(n=100)
    hof = tools.HallOfFame(10)
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("min", np.min, axis=0)
    
    
    pop, logbook = eaNSGA3(
        pop, toolbox,
        ref_points=ref_points,  
        mu=100, lambda_=100,
        cxpb=0.7, mutpb=0.3,
        ngen=ngen,
        stats=stats,
        halloffame=hof,
        verbose=True
    )



def main(ngen=100):
    pop = toolbox.population(n=100)
    hof = tools.HallOfFame(10)  
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("min", np.min, axis=0)
    pop, logbook = algorithms.eaMuPlusLambda(
        pop, toolbox, mu=100, lambda_=100, 
        cxpb=0.7, mutpb=0.3, ngen=ngen,
        stats=stats,
        halloffame=hof,
        verbose=True,
        selection=toolbox.select
    )
    return pop, hof, logbook

if __name__ == "__main__":
    population = main()
    pareto_front = tools.sortNondominated(population, len(population))[0]
    result = []
    for ind in pareto_front:
        
        x_values = [ind[i] for i in range(len(VAR_RANGES))]
        
        y_values = ind.fitness.values
        result.append(x_values + list(y_values))
    
    
    columns = [name for name, _, _ in VAR_RANGES] + ["1/Flowrate", "Pressure Drop"]
    
    
    df = pd.DataFrame(result, columns=columns)
    
    
    df = df.round({
        "温度": 4,
        "比例": 4,
        "速度": 4,
        "1/Flowrate": 4,
        "Pressure Drop": 4
    })
    
    output_path = "C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end\\pareton_GPR100_IIITRY.csv"
    df.to_csv(output_path, index=False)

    print(f"\n帕累托前沿数据已保存至:{output_path}")
    print(f"数据预览：\n{df.head()}")

plt.rcParams['font.sans-serif'] = ['SimHei']  
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(8, 6))  

plt.scatter(
    1/((y_flowrate_train*0.20357741299999998+0.461649184)),
    
    
    y_pressuredrop_train_end,
    alpha=0.8,
    label='模型预测数据'
)

plt.scatter([ind.fitness.values[0] for ind in pareto_front], [ind.fitness.values[1] for ind in pareto_front], c='red',marker='*', s=150,label='帕累托前沿')

plt.xlabel("1/Flowrate", fontsize=12)  
plt.ylabel("Pressure Drop", fontsize=12)
plt.title("帕累托前沿与模型预测数据对比", fontsize=14)
plt.legend(fontsize=10)
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()  
plt.show()















    
with open('pareto_solutions.txt', 'w') as f:
        f.write("温度,比例,速度,1/流量,压降\n")
        for ind in pareto_front:
            f.write(f"{ind[0]:.2f},{ind[1]:.2f},{ind[2]:.4f},")
            f.write(f"{ind.fitness.values[0]:.4f},{ind.fitness.values[1]:.2f}\n")
    
    
print(f"找到{len(pareto_front)}个帕累托解，变量范围均在约束内：")
for i, (name, low, high) in enumerate(VAR_RANGES):
        values = [ind[i] for ind in pareto_front]
        print(f"{name}: 最小{min(values):.2f}，最大{max(values):.2f}（约束{low}-{high}）")







VAR_RANGES = [
    ('温度', 500, 675),   
    ('比例', 0.05, 0.2),   
    ('速度', 1.5, 5.5)    
]


creator.create("FitnessMulti", base.Fitness, weights=(-1.0, -1.0))
creator.create("Individual", list, fitness=creator.FitnessMulti)

toolbox = base.Toolbox()


def create_individual():
    return [random.uniform(low, high) for _, low, high in VAR_RANGES]
toolbox.register("individual", tools.initIterate, creator.Individual, create_individual)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)


def evaluate(individual):
    norm_vars = []
    for i, (_, low, high) in enumerate(VAR_RANGES):
        val = individual[i]
        norm_vars.append((val - low) / (high - low))  
    
    
    flow = float(Gboost_flowrate.predict([norm_vars])[0])
    press = float(Gboost_pressuredrop.predict([norm_vars])[0])
    flow = max(flow, 1e-6)  
    return (1/flow, press)  
toolbox.register("evaluate", evaluate)



VAR_WIDTHS = [high - low for _, low, high in VAR_RANGES]  
MUT_SIGMAS = [width * 0.05 for width in VAR_WIDTHS]  


toolbox.register("mate", tools.cxSimulatedBinaryBounded, 
                 eta=20, low=[low for _, low, _ in VAR_RANGES], 
                 up=[high for _, _, high in VAR_RANGES])  


toolbox.register("mutate", tools.mutGaussian, 
                 mu=0, sigma=MUT_SIGMAS, indpb=0.3)  


def check_bounds(mins, maxs):
    def decorator(func):
        def wrapper(*args, **kargs):
            offspring = func(*args, **kargs)
            for child in offspring:
                for i in range(len(child)):
                    child[i] = max(min(child[i], maxs[i]), mins[i])  
            return offspring
        return wrapper
    return decorator
VAR_MINS = [low for _, low, _ in VAR_RANGES]
VAR_MAXS = [high for _, _, high in VAR_RANGES]
toolbox.mate = check_bounds(VAR_MINS, VAR_MAXS)(toolbox.mate)
toolbox.mutate = check_bounds(VAR_MINS, VAR_MAXS)(toolbox.mutate)
toolbox.register("select", tools.selNSGA3)  


def main(ngen=100):  
    pop = toolbox.population(n=800)  
    
    pop, logbook = algorithms.eaMuPlusLambda(
        pop, toolbox, mu=100, lambda_=100,  
        cxpb=0.8, mutpb=0.2,  
        ngen=ngen
    )
    return pop

if __name__ == "__main__":
    population = main()
    pareto_front = tools.sortNondominated(population, len(population))[0]

    
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(figsize=(10, 7))
    
    plt.scatter([ind.fitness.values[0] for ind in pareto_front], 
                [ind.fitness.values[1] for ind in pareto_front], 
                c='r', label='帕累托前沿')
    plt.xlabel('1/流量')
    plt.ylabel('压降')
    plt.title('优化后的帕累托前沿')
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()
    plt.scatter(
    1/(y_flowrate_train+1e-8),
    
    y_pressuredrop_train,
    c='blue',
    alpha=0.5,
    label='模型预测数据'
)

plt.scatter([ind.fitness.values[0] for ind in pareto_front], [ind.fitness.values[1] for ind in pareto_front], c='red',marker='*', s=150,label='帕累托前沿')

plt.xlabel("1/Flowrate", fontsize=12)  
plt.ylabel("Pressure Drop", fontsize=12)
plt.title("帕累托前沿与模型预测数据对比", fontsize=14)
plt.legend(fontsize=10)
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()  
plt.show()

import random
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
import joblib
from deap import base, creator, tools, algorithms
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import LinearRegression
import tensorflow as tf
import joblib


da = pd.read_csv("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\end.csv")
data = np.array(da)
dataa = data.copy()

dataa[:, 0] = (data[:, 0] - np.min(data[:, 0])) / (np.max(data[:, 0]) - np.min(data[:, 0]))  
dataa[:, 1] = (data[:, 1] - np.min(data[:, 1])) / (np.max(data[:, 1]) - np.min(data[:, 1]))  
dataa[:, 2] = (data[:, 2] - np.min(data[:, 2])) / (np.max(data[:, 2]) - np.min(data[:, 2]))  
dataa[:, 3] = (data[:, 3] - np.min(data[:, 3])) / (np.max(data[:, 3]) - np.min(data[:, 3]))  


delta=(np.max(data[:, 4]) - np.min(data[:, 4])) 
delta_min=np.min(data[:, 4])

xaa = dataa[:, :4]  
ya = dataa[:, 4]    


fixed_train_xa = xaa[:12]
fixed_train_ya = ya[:12]
remaining_xa = xaa[12:]
remaining_ya = ya[12:]

perm = np.random.permutation(len(remaining_xa))
split_idx = int(len(remaining_xa) * 0.8)
train_remaining_xa = remaining_xa[perm[:split_idx]]
train_remaining_ya = remaining_ya[perm[:split_idx]]
val_xa = remaining_xa[perm[split_idx:]]
val_ya = remaining_ya[perm[split_idx:]]


x_train_final = np.vstack([fixed_train_xa, train_remaining_xa])
y_train_final = np.hstack([fixed_train_ya, train_remaining_ya])



Gboost_flowrateSVR = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\\SVR\\norm_oil.pkl")

Gboost_flowrateANN = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\\ANN\\norm_oil.pkl")



Gboost_flowrate = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\\GPR\\best_gpr_oil.pkl")

Gboost_flowrateRF = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\\RF\\1_oil.pkl")

Gboost_flowrateGBOOST = joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\ML_models\\ML_models_examples\\qin\\gboost\\best_modeloil.pkl")



Gboost_flowrate= joblib.load("C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\gpr\\gpr_rbf_white_oil.pkl")

mu, sigma = Gboost_flowrate.predict(val_xa, return_std=True)
print(Gboost_flowrate.kernel_)

py = val_ya
n = py.shape[0]
py = np.reshape(py, [n])
mu = np.reshape(mu, [n])
sigma = np.reshape(sigma, [n])


lower = mu - 1.96 * sigma
upper = mu + 1.96 * sigma


scale_factor = 1.0 
scaled_sigma = sigma * scale_factor


plt.style.use('default')
plt.rcParams.update({
    'figure.dpi': 150,
    'savefig.dpi': 600,
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']
})


plt.figure(figsize=(6.4, 4.8))


plt.errorbar(
    py, mu,
    yerr=scaled_sigma,      
    fmt='o',                
    color='
    ecolor='gray',          
    elinewidth=1.5,         
    capsize=4,              
    capthick=1.5,
    markersize=6 + len(mu)//20,  
    alpha=0.8,
    zorder=2,
    label=f'GPR prediction ±95% CI (×{scale_factor} visual scale)'
)


plt.plot([py.min(), py.max()], [py.min(), py.max()],
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')


plt.grid(linestyle='--', alpha=0.5, zorder=1)
plt.xlabel('Actual value', weight='bold', fontsize=15)
plt.ylabel('Predicted value', weight='bold', fontsize=15)
plt.title('GPR Prediction on Validation Set with 95% Confidence Intervals', fontsize=13)
plt.legend()
plt.tight_layout(pad=0.6)
plt.show()












pyy_GPR=Gboost_flowrate.predict(val_xa,return_std=False)
py=val_ya 
y2_gpr=pyy_GPR
n=py.shape[0]
py = np.reshape(py,[n])
y2_gpr = np.reshape(y2_gpr,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_gpr)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter(py, y2_gpr,s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli GPR')
plt.tight_layout(pad=0.6)












pyy_SVR=Gboost_flowrateSVR.predict(val_xa)
py=val_ya*delta+delta_min
y2_SVR= pyy_SVR*delta+delta_min
n=py.shape[0]
py = np.reshape(py,[n])
y2_SVR = np.reshape(y2_SVR,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_SVR)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter( py,y2_SVR, s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli SVR')
plt.tight_layout(pad=0.6)



pyy_RF=Gboost_flowrateRF.predict(val_xa)
py=val_ya
y2_RF=pyy_RF
n=py.shape[0]
py = np.reshape(py,[n])
y2_RF = np.reshape(y2_RF,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_RF)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter(py, y2_RF, s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli RF')
plt.tight_layout(pad=0.6)



pyy_GBOOST=Gboost_flowrateGBOOST.predict(val_xa)
py= val_ya
y2_GBOOST=pyy_GBOOST
n=py.shape[0]
py = np.reshape(py,[n])
y2_GBOOST = np.reshape(y2_GBOOST,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_GBOOST)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter( py,y2_GBOOST, s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli GBOOST')
plt.tight_layout(pad=0.6)



def create_poly_features(X, degree):
    """生成无交叉项的多项式特征"""
    n_samples, n_features = X.shape
    poly_features = []
    for i in range(n_features):
        for d in range(1, degree + 1):
            poly_features.append(X[:, i] ** d)
    return np.column_stack(poly_features)

X_poly_val = create_poly_features(val_xa, 2)
pyy_polyr=Gboost_flowratepolyr.predict(X_poly_val)
py=val_ya
y2_polyr= pyy_polyr
n=py.shape[0]
py = np.reshape(py,[n])
y2_polyr = np.reshape(y2_polyr,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_polyr)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter( py, y2_polyr,s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli polyr')
plt.tight_layout(pad=0.6)



pyy_ANN=Gboost_flowrateANN.predict(val_xa)
py=val_ya*delta+delta_min
y2_ANN= pyy_ANN*delta+delta_min
n=py.shape[0]
py = np.reshape(py,[n])
y2_ANN = np.reshape(y2_ANN,[n])
plt.style.use('default')  
plt.rcParams.update({
    'figure.dpi': 150,       
    'savefig.dpi': 600,      
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial']  
})
SCATTER_PARAMS = {
    'marker': 'o',
    'color': '
    'edgecolor': 'white',
    'linewidth': 1.2,        
    's': 14 + len(y2_ANN)//10,   
    'alpha': 0.8,
    'zorder': 2  
}


plt.figure(figsize=(6.4, 4.8))
plt.scatter( py,y2_ANN, s = 20)  

plt.plot([py.min(), py.max()], [py.min(), py.max()], 
         'k--', lw=2.0, alpha=0.7, label='1:1 Line')  


plt.grid(linestyle='--', alpha=0.5, zorder=1)  
plt.xlabel('Actual value ', weight='bold', fontsize=15)
plt.ylabel('predict value ', weight='bold', fontsize=15)
plt.title('trained data of oli ANN')
plt.tight_layout(pad=0.6)






val_xa_original = np.zeros_like(val_xa)
for i in range(4):
    val_xa_original[:, i] = val_xa[:, i] * (np.max(data[:, i]) - np.min(data[:, i]) ) + np.min(data[:, i])



print("验证集特征维度:", val_xa_original.shape)         
print("预测值维度:", py.shape)                
print("真实值维度:", y2_ANN.shape)            
print("真实值维度:", y2_SVR.shape)            


py_2d = py[:, np.newaxis]   
y2_ANN_2d = y2_ANN[:, np.newaxis]   
y2_SVR_2d = y2_SVR[:, np.newaxis]   



columns = ['Temp', 'Ratio', 'height', 'velocity', 'CFD_data', 'pre_ANN', 'pre_SVR']


dataout = np.hstack([
    val_xa_original,   
    py_2d,       
    y2_ANN_2d,       
    y2_SVR_2d        
])

df = pd.DataFrame(dataout, columns=columns)


output_path = "C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\val_oliNNORM.csv"
df.to_csv(output_path, index=False, float_format='%.6f')  

print(f"\n数据已保存至：{output_path}")
print(f"数据前5行预览：\n{df.head()}")



print("验证集特征维度:", val_xa_original.shape)  
print("预测值维度:", py.shape) 
print("真实值维度:", y2_RF.shape)             
print("真实值维度:", y2_GBOOST.shape)         

print("真实值维度:", y2_gpr.shape)            


y2_CFD_2d = py[:, np.newaxis]          
py_RF_2d = y2_RF[:, np.newaxis]           
py_GBOOST_2d = y2_GBOOST[:, np.newaxis]   

py_gpr_2d = y2_gpr[:, np.newaxis]         


columns = ['Temp', 'Ratio', 'height', 'velocity', 'CFD_data', 'pre_RF', 'pre_GBOOST', 'pre_gpr']


dataout = np.hstack([
    val_xa_original,    
    y2_CFD_2d,          
    py_RF_2d,           
    py_GBOOST_2d,       
    
    py_gpr_2d           
])

df = pd.DataFrame(dataout, columns=columns)


output_path = "C:\\Users\\13279\\Desktop\\qinling\\ICER_HDPE_rejie\\朱老师AICHE论文\\ML_models\\ML_models_examples\\qin\\mul_optimazation\\val_oli.csv"
df.to_csv(output_path, index=False, float_format='%.6f')

print(f"\n数据已保存至：{output_path}")
print(f"数据前5行预览：\n{df.head()}")



